import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import './App.css';
import CoursesPage from './Generos/GenerosPage';
import TeachersPage from './Bandas/BandaPage';
import TeacherCreate from './Bandas/BandaCreate';
import TeacherUpdate from './Bandas/BandaUpdate';
import Course from './Generos/Course';
import Navbar from "./components/Navbar";

function App () {

  return (
      
    <BrowserRouter>
    <Navbar />
      <Routes>
        <Route path="/teachers" element={<TeachersPage />} />
        <Route path="/courses" element={ <CoursesPage />   }/>         
        <Route path="/course" element={ <Course />   }/>                 
        <Route path="/createteacher" element={ <TeacherCreate />   }/>   
        <Route path="/updateteacher/:teacherId" element={ <TeacherUpdate />   }/>   
        
      </Routes>

    </BrowserRouter>   
  );
}

export default App;