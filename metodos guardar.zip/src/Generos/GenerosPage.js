function GenerosPage(props){
return(
    <p>
        ++++++++++++++++++++++++++++++++++++++GENEROS DEL ROCK+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    </p>
);

}
export default GenerosPage