import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { findByIdTeacher,updateTeacher } from '../service/BandaService'
import './Banda.css'

function BandaPage() {
  
  const { teacherId } = useParams();
  const [teacher, setTeacher] = useState({nombre:'',vocalista:'',guitarrista:'',baterista:'',bajista:''});

  const onSubmit = (event) => {
    event.preventDefault();
    updateTeacher(teacher);
    alert ('CAMBIOS REALIZADOS')

  }
  const onChange = (event) =>{
    if(event.target.name==='nombre')
      setTeacher({...teacher,nombre:event.target.value})    
    if(event.target.name==='vocalista')    
      setTeacher({...teacher,vocalista:event.target.value})
    if(event.target.name==='guitarrista')
      setTeacher({...teacher,guitarrista:event.target.value})
    if(event.target.name==='baterista')    
      setTeacher({...teacher,baterista:event.target.value})
    if(event.target.name==='bajista')
      setTeacher({...teacher,bajista:event.target.value})
  }

  useEffect(() => {    
    findByIdTeacher(teacherId).then(data => {
      setTeacher(data);  
    }
    );
  }, [teacherId]);

  return (
    <div className="boxUpdate">
      <form onSubmit={onSubmit} className="boxFormUpdate">
      <h2>CAMBIAR LOS DATOS DE BANDA</h2>
  
          <input 
          className="formUpdateInput"
            name="nombre"
            placeholder="nombre" 
            value={teacher.nombre}
            onChange={onChange}
   
          />
  
          <input 
           className="formUpdateInput"
           placeholder="vocalista" 
            name="vocalista"
            value={teacher.vocalista}
            onChange={onChange}
          />
        
          <input 
           className="formUpdateInput"
           placeholder="guitarrista"
            name="guitarrista"
            value={teacher.guitarrista}
            onChange={onChange}
          />
           
        
        <input 
         className="formUpdateInput"
         placeholder="baterista"
          name="baterista"
          value={teacher.baterista}
          onChange={onChange}
        />
        
        
        <input 
         className="formUpdateInput"
         placeholder="bajista"
          name="bajista"
          value={teacher.bajista}
          onChange={onChange}
        />
        

        <button type="submit" className="formUpdateBtn">GUARDAR DATOS</button>
        

      </form>
      
    </div>
  );
}

export default BandaPage;