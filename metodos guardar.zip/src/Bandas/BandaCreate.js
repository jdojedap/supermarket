import React, { useState } from "react";
import { createTeacher } from '../service/BandaService'

function BandaCreate() {

  const [nombre, setnombre] = useState('');
  const [vocalista, setvocalista] = useState('');
  const [guitarrista, setguitarrista] = useState('');
  const [baterista, setbaterista] = useState('');
  const [bajista, setbajista] = useState('');


  const onSubmit = (event) => {
    event.preventDefault();
    const objeto = {
      nombre: nombre,
      vocalista: vocalista,
      guitarrista: guitarrista,
      baterista: "baterista",
      bajista: "bajista",
    }
    createTeacher(objeto)

  }

  const onChange = (event) =>{
    if(event.target.name==='nombre')
    {
    setnombre(event.target.value)
    }
    if(event.target.name==='vocalista')
    setvocalista(event.target.value)

    if(event.target.name==='guitarrista')
    setguitarrista(event.target.value)

    if(event.target.name==='baterista')
    setbaterista(event.target.value)

    if(event.target.name==='bajista')
    setbajista(event.target.value)
  }

  return (
    <div>
      <h2>AGREGAR BANDA</h2>
      <form onSubmit={onSubmit}>
        <label>
          nombre
          <input 
            name="nombre"
            value={nombre}
            onChange={onChange}
          />
        </label>
        <label>
          vocalista
          <input 
            name="vocalista"
            value={vocalista}
            onChange={onChange}
          />
        </label>
        <label>
          guitarrista
          <input 
            name="guitarrista"
            value={guitarrista}
            onChange={onChange}
          />
        </label>

        <label>
          baterista
          <input 
            name="baterista"
            value={baterista}
            onChange={onChange}
          />
        </label>

        <label>
          bajista
          <input 
            name="bajista"
            value={bajista}
            onChange={onChange}
          />
        </label>

        <button type="submit">Guardar</button>
      </form>
    </div>
  );
}

export default BandaCreate;