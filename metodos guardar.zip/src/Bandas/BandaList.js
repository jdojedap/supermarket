
function BandaList(props){
return(
    <table>
    <thead >
      <tr>
        <th >BANDA</th>
        <th>VOCALISTA</th>
        <th>GUITARRISTA</th>
        <th>BATERISTA</th>
        <th>BAJISTA</th>
      </tr>
    </thead>
    <tbody>
    
        {props.children}
    
        </tbody>
  </table>
);
}

export default BandaList