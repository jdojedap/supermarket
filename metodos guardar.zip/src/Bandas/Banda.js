import { Link } from "react-router-dom";
import './Banda.css'

function Banda(props){
   
return(
    <tr > 
        <td>{props.itemTeacher.nombre}</td>        
        <td> {props.itemTeacher.vocalista} </td>
        <td> {props.itemTeacher.guitarrista} </td>
        <td>{props.itemTeacher.baterista}</td>        
        <td> {props.itemTeacher.bajista} </td>
        <td><Link to={`/updateteacher/${props.itemTeacher.id}`}>CAMBIAR DATOS</Link></td>
        
    </tr>
);

}
export default Banda