import './Navbar.css'
import { NavLink } from "react-router-dom";
export default function Navbar() {

    return (
        <ul>
            <li>
                <NavLink to={"/teachers"} className="navlink">
                    BANDAS ROCK
                </NavLink>

            </li>
            <li>
                <NavLink to={"/courses"} className="navlink">
                    GENEROS DE ROCK
                </NavLink>
            </li>
            
        </ul>

    );

}